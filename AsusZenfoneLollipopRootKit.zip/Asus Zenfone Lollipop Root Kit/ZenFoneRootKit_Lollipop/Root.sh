#!/bin/sh

BASEDIR=$(dirname $0)
cd $BASEDIR

chmod +x files/adb.mac
chmod +x files/fastboot.mac

ADBBINARY="adb.mac"
FASTBOOTBINARY="fastboot.mac"

cd ./files

echo 
echo
echo Connect your device with your computer and prepare to ROOT
echo
echo !!! DO NOT DISCONNECT USB CABLE WHILE ROOTING !!!
echo
echo
./${ADBBINARY} wait-for-devices
./${ADBBINARY} reboot bootloader
sleep 30

echo
echo
echo Rooting, please be patient ..
echo
echo
./${FASTBOOTBINARY} flash /system/bin/resize2fs magic
./${FASTBOOTBINARY} flash /system/bin/tune2fs busybox
./${FASTBOOTBINARY} flash /system/bin/partlink supersu.tgz
./${FASTBOOTBINARY} oem start_partitioning
./${FASTBOOTBINARY} flash /system/bin/logcat installer
./${FASTBOOTBINARY} oem stop_partitioning
sleep 2

echo
echo
echo "All done, enjoy your ROOTED device :)"
echo "by shakalaca (http://23pin.logdown.com)"
echo
echo
./${FASTBOOTBINARY} reboot
